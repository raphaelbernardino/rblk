### About files
1. drive.cs: This code is the main file for Q# compiler with C#.
2. Program.qs: This code consists of Q# circuits. Especially, there is a circuit for AES sbox and manually made MCT gates.
3. QUtilities.qs: To compare circuit with previous results, code used in work from Samuel Jaques and Fernando Virdia is used. (see, https://github.com/microsoft/grover-blocks/tree/master/aes)
</br>
