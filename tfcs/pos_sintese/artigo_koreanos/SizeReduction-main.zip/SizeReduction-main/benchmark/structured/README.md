## Results for other structured functions with various d_j 

Following functions are considered.
- Hidden weighted bit function (HWB)
  - HWB function might have polynomial cost circuit (https://arxiv.org/abs/2007.05469)
- Hamming coding function

Although proposed algorithm wouldn't give better circuit for structured functions, the algorithm is applied for the functions.
The result circuits are presented each folders.
